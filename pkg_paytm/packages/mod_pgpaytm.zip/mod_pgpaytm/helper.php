<?php
error_reporting(E_ALL & ~E_NOTICE);
define('_JEXEC', 1);
define( 'JPATH_BASE', realpath(dirname(__FILE__).'/../../' )); 
include_once ( JPATH_BASE .'/includes/defines.php' );
include_once ( JPATH_BASE .'/includes/framework.php' );

class modPgPaytmHelper
{
	public static function saveData($orderid, $custid, $email, $mobile, $amount)
	{
		$db=JFactory::getDBO();
		$query="INSERT INTO `#__pgdata`(`order_id`, `cust_id`, `email`, `mobile`, `amount`) VALUES ('$orderid', '$custid', '$email', '$mobile', '$amount')";
		$db->setQuery($query);
		if($db->query())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public static function saveTransactionData($orderid, $amount, $txnid, $status, $txndate)
	{
		$db=JFactory::getDBO();
		$query="INSERT INTO `#__pgstatus`(`order_id`, `amount`, `txnid`, `status`, `txndate`) VALUES ('$orderid', '$amount', '$txnid', '$status', '$txndate')";
		$db->setQuery($query);
		if($db->query())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
?>