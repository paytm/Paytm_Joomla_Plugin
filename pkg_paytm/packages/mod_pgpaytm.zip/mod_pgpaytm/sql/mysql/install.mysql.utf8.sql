CREATE TABLE IF NOT EXISTS `#__pgdata` (
	`id` int(10) NOT NULL AUTO_INCREMENT,
	`order_id` varchar(250) NOT NULL,
	`cust_id` varchar(250) NOT NULL,
	`email` varchar(250) NOT NULL,
	`mobile` varchar(12) NOT NULL,	
	`amount` int(10) NOT NULL,	
    `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `#__pgstatus` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(50) NOT NULL,
  `amount` varchar(10) NOT NULL,
  `txnid` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `txndate` datetime NOT NULL,
  
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;