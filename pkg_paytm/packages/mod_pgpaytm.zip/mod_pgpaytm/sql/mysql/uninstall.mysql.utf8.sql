DROP TABLE IF EXISTS `#__pgdata`;
DROP TABLE IF EXISTS `#__pgstatus`;