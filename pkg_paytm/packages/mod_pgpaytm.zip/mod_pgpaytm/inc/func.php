<?php
/**
 * @package   PGPAYTM
 * @contact   www.paytm.com
 * @copyright 2010 paytm.com
 */

// no direct access
defined('_JEXEC') or die();

function stripDoubleSlashes($url)
{
    preg_match('/^.+?[^\/:](?=[?\/])|$/', $url, $matches);
    return $matches[0];
}
