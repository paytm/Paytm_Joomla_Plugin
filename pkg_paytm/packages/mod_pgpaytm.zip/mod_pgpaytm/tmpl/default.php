<?php
/**
 * @package   PGPAYTM
 * @contact   www.paytm.com
 * @copyright 2020 paytm.com
 */
// no direct access
defined('_JEXEC') or die();
JHtml::_('behavior.formvalidator');

include_once(JPATH_BASE . '/modules/mod_pgpaytm/inc/func.php');
include_once(JPATH_BASE . '/modules/mod_pgpaytm/inc/PaytmChecksum.php');
include_once(JPATH_BASE . '/modules/mod_pgpaytm/inc/PaytmHelper.php');
//include_once(JPATH_BASE . '/modules/mod_pgpaytm/inc/config_paytm.php');
include_once(JPATH_BASE . '/modules/mod_pgpaytm/helper.php');

$redirect_url = '';

$document = JFactory::getDocument();
$document->addStyleSheet(JURI::base() . 'modules/mod_pgpaytm/css/style.css');


$langSite = substr($params->get('locale'), 3, 2);

if (!$langSite) {
    $langSite = 'US';
}
$introtext = '';
if ($params->get('show_text', 1)) {
    $introtext = '<p class="osdonate-introtext">' . $params->get('intro_text', '') . '</p>' . "\n";
}

$amountLine = '';
if (!$params->get('show_amount')) {
    $amountLine .= '<input type="hidden" name="TXN_AMOUNT" value="' . $params->get('amount') . '" />' . "\n";
} else {
    $amountLine .= '<div class="pg-amount-label"><p>' . JText::_($params->get('amount_label')) . '*:' . '</p></div>'
            . '<div class="pg-amount-field"><input  class="required validate-numeric" type="text" name="TXN_AMOUNT" tabindex="7" size="10" maxlength="10" value="' . $params->get('amount') . '"
                /></div>' . "\n";
}

$currencies = explode(',', $params->get('currencies'));
$availableCurrencies = array(
    'EUR',
    'USD',
    'INR',
    'GBP',
    'BRL',
    'CHF',
    'AUD',
    'HKD',
    'CAD',
    'JPY',
    'NZD',
    'SGD',
    'SEK',
    'DKK',
    'PLN',
    'NOK',
    'HUF',
    'CZK',
    'ILS',
    'MXN'
);

$sizeOfCurr = sizeof($currencies);
for ($i = 0; $i < $sizeOfCurr; $i++) {
    for ($j = 0; $j < sizeof($availableCurrencies); $j++) {
        if ($currencies[$i] === $availableCurrencies[$j]) {
            $isOk = 1;
            break;
        }
    }
    if (!$isOk) {
        unset($currencies[$i]);
    }
    $isOk = 0;
}

if (sizeof($currencies) == 0) {
    $amountLine = '<p class="error">' . JText::_('Error - no currencies selected!') . '<br/>' . JText::_(
                    'Please check the backend parameters!'
            ) . '</p>';
    $fe_c = '';
} else {
    if (sizeof($currencies) == 1) {
        $fe_c = '<input type="hidden" name="currency_code" value="' . $currencies[0] . '" />' . "\n";
        if ($params->get('show_amount', 1)) {
            $fe_c .= '&nbsp;' . $currencies[0] . "\n";
        }
    } else {
        if (sizeof($currencies) > 1) {
            if ($params->get('show_amount', 1)) {
                $fe_c = '<select name="currency_code">' . "\n";
                foreach ($currencies as $row) {
                    $fe_c .= '<option value="' . $row . '">' . $row . '</option>' . "\n";
                }
                $fe_c .= '</select>' . "\n";
            } else {
                $fe_c = '<input type="hidden" name="currency_code" value="' . $currencies[0] . '" />' . "\n";
            }
        }
    }
}

$application = JFactory::getApplication();

$returnMenuListIds = array(
    $params->get('return', ''),
    $params->get('cancel_return', '')
);

$sticky = '';
$sticky .= "<div id=\"osdonatestatic\">";
/* Define Paytm Merchant Parameters */
define('PAYTM_ENVIRONMENT', $params->get('paytm_environment')); // PROD
//define('PAYTM_TRANSACTION_URL', $params->get('paytm_transaction_url')); // transaction url
//define('PAYTM_TRANSACTION_STATUS_URL', $params->get('paytm_transaction_status_url')); // transaction status url
define('PAYTM_MERCHANT_KEY', $params->get('paytm_merchant_key')); //Change this constant's value with Merchant key downloaded from portal
define('PAYTM_MERCHANT_MID', $params->get('paytm_merchant_mid')); //Change this constant's value with MID (Merchant ID) received from Paytm
define('PAYTM_MERCHANT_WEBSITE', $params->get('paytm_merchant_website')); //Change this constant's value with Website name received from Paytm
/* Define Paytm Merchant Parameters */
if (PAYTM_ENVIRONMENT == 'PROD') {
    $PAYTM_ENV = 1;
} else {

    $PAYTM_ENV = 0;
}

/* PAYTM  FLOW */
if ($_POST["INDUSTRY_TYPE_ID"] != '') {
    $checkSum = "";
    $paramList = array();
    $callback_url = JURI::current() . '?PaytmRes=true';

    $ORDER_ID = $_POST["ORDER_ID"];
    $CUST_ID = $_POST["email"];
    $INDUSTRY_TYPE_ID = $_POST["INDUSTRY_TYPE_ID"];
    $CHANNEL_ID = $_POST["CHANNEL_ID"];
    $email = $_POST["email"];
    $mobile = $_POST["mobile"];
    $TXN_AMOUNT = $_POST["TXN_AMOUNT"];

    // Create an array having all required parameters for creating checksum.
    $paramList["MID"] = PAYTM_MERCHANT_MID;
    $paramList["ORDER_ID"] = $ORDER_ID;
    $paramList["CUST_ID"] = $CUST_ID;
    $paramList["INDUSTRY_TYPE_ID"] = $INDUSTRY_TYPE_ID;
    $paramList["CHANNEL_ID"] = $CHANNEL_ID;
    $paramList["TXN_AMOUNT"] = $TXN_AMOUNT;
    $paramList["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;
    $paramList["MSISDN"] = $_POST["mobile"];
    if ($params->get('show_callback') == '1') {
        $paramList["CALLBACK_URL"] = $redirect_url;
    }

    modPgPaytmHelper::saveData($ORDER_ID, $CUST_ID, $email, $mobile, $TXN_AMOUNT);
    //Here checksum string will return by getChecksumFromArray() function.
    //$checkSum = getChecksumFromArray($paramList,PAYTM_MERCHANT_KEY);
    $paytmParams = array();
    $paytmParams["body"] = $paramList;
    $paytmParams["body"] = array(
        "requestType" => "Payment",
        "mid" => PAYTM_MERCHANT_MID,
        "websiteName" => PAYTM_MERCHANT_WEBSITE,
        "orderId" => $ORDER_ID,
        "callbackUrl" => $callback_url,
        "txnAmount" => array(
            "value" => $TXN_AMOUNT,
            "currency" => "INR",
        ),
        "userInfo" => array(
            "custId" => $CUST_ID,
        ),
    );

    $generateSignature = PaytmChecksum::generateSignature(json_encode($paytmParams['body'], JSON_UNESCAPED_SLASHES), PAYTM_MERCHANT_KEY);

    $paytmParams["head"] = array(
        "signature" => $generateSignature
    );

    $apiURL = PaytmHelper::getPaytmURL(PaytmConstants::INITIATE_TRANSACTION_URL, $PAYTM_ENV) . '?mid='.PAYTM_MERCHANT_MID.'&orderId='.$ORDER_ID;

    $post_data_string = json_encode($paytmParams, JSON_UNESCAPED_SLASHES);
    $response = PaytmHelper::executecUrl($apiURL, $post_data_string);
    if(!empty($response['body']['txnToken'])){
        $data['txnToken'] = $response['body']['txnToken'];
        $data['message'] =  PaytmConstants::TXN_TOKEN_SUCCESS;
    }else{
        $data['txnToken'] = '';
        $data['message'] = PaytmConstants::SOMETHING_WENT_WRONG;
    }
    
    echo json_encode(array('response'=>$data)); 
    exit;
    ?>

<?php
} elseif ($_GET['PaytmRes'] == "true")
/* PAYTM RESPONSE FLOW */ {
    $paytmChecksum = "";
    $paramList = array();
    $isValidChecksum = "FALSE";

    $paramList = $_POST;
    $paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; //Sent by Paytm pg
    //$paramList = array_pop()
    //Verify all parameters received from Paytm pg to your application. Like MID received from paytm pg is same as your application’s MID, TXN_AMOUNT and ORDER_ID are same as what was sent by you to Paytm PG for initiating transaction etc.
    // $isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); //will return TRUE or FALSE string.
    $isValidChecksum = PaytmChecksum::verifySignature($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum);

    if ($isValidChecksum == "TRUE" || $isValidChecksum == "true" || $isValidChecksum == "1") {
        //echo "<b>Checksum matched and following are the transaction details:</b>" . "<br/>";
        if ($_POST["STATUS"] == "TXN_SUCCESS") {
            // Create an array having all required parameters for status query.
            $requestParamList = array("MID" => PAYTM_MERCHANT_MID, "ORDERID" => $_POST['ORDERID']);
            /* initialize an array */
            $paytmParamsStatus = array();

            /* body parameters */
            $paytmParamsStatus["body"] = array(
                /* Find your MID in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys */
                "mid" => PAYTM_MERCHANT_MID,
                /* Enter your order id which needs to be check status for */
                "orderId" => $_POST['ORDERID'],
            );
            $checksumStatus = PaytmChecksum::generateSignature(json_encode($paytmParamsStatus["body"], JSON_UNESCAPED_SLASHES), PAYTM_MERCHANT_KEY);
            /* head parameters */
            $paytmParamsStatus["head"] = array(
                /* put generated checksum value here */
                "signature" => $checksumStatus
            );
            /* prepare JSON string for request */
            $post_data_status = json_encode($paytmParamsStatus, JSON_UNESCAPED_SLASHES);
            $responseStatusArray = PaytmHelper::executecUrl(PaytmHelper::getPaytmURL(PaytmConstants::ORDER_STATUS_URL, $PAYTM_ENV), $post_data_status);
            //$responseStatusArray = json_decode($responseJson, true);
            if ($responseStatusArray['body']['resultInfo']['resultStatus'] == 'TXN_SUCCESS' && $responseStatusArray['body']['txnAmount'] == $_POST['TXNAMOUNT']) {
                modPgPaytmHelper::saveTransactionData($_POST["ORDERID"], $_POST["TXNAMOUNT"], $_POST["TXNID"], $_POST["STATUS"], date("Y-m-d H:i:s"));
                echo '<p style="font-size: 18px;background: #eee;border-radius: 3px;padding:8px">Your order has been placed successfully with order id ' . $_POST["ORDERID"] . '</p>';
                echo '<p style="font-size: 14px;">Below are the Transaction details:</p>';
                ?>
                <table border="1" style="border: 2px #d1d1d1 solid;margin: 10px 0;width: 50%; text-align: center;">
                    <tbody>
                        <tr>
                            <td><b>Order ID</b></td>
                            <td><?php echo $_POST["ORDERID"]; ?></td>
                        </tr>
                        <tr>
                            <td><b>Amount</b></td>
                            <td><?php echo $_POST["TXNAMOUNT"]; ?></td>
                        </tr>
                        <tr>
                            <td><b>Transaction ID</b></td>
                            <td><?php echo $_POST["TXNID"]; ?></td>
                        </tr>
                        <tr>
                            <td><b>Status</b></td>
                            <td><?php if ($_POST["STATUS"] == "TXN_SUCCESS") {
                    echo "Success";
                } else {
                    echo "Failed";
                } ?></td>
                        </tr>
                        <tr>
                            <td><b>Response</b></td>
                            <td><?php echo $_POST["RESPMSG"]; ?></td>
                        </tr>
                    </tbody>
                </table>
                <?php
            } else {
                echo '<p style="font-size: 14px;color:#b94a48;background: #f2dede;border-radius: 3px;padding:8px">It seems some issue in server to server communication. Kindly connect with administrator.</p>';
            }
            //Process your transaction here as success transaction.
            //Verify amount & order id received from Payment gateway with your application's order id and amount.
        } else {
            modPgPaytmHelper::saveTransactionData($_POST["ORDERID"], $_POST["TXNAMOUNT"], $_POST["TXNID"], $_POST["STATUS"], date("Y-m-d H:i:s"));
            echo '<p style="font-size: 14px;color:#b94a48;background: #f2dede;border-radius: 3px;padding:8px">Oops! Your order get failed due to ' . $_POST["RESPMSG"] . '</p>';
        }
        /* if (isset($_POST) && count($_POST)>0 )
          {
          foreach($_POST as $paramName => $paramValue) {
          echo "<br/>" . $paramName . " = " . $paramValue;
          }
          } */
    } else {
        echo "<b>Checksum mismatched.</b>";
        //Process transaction as suspicious.
    }
}
/* PAYTM RESPONSE FLOW */ else { /* PAYTM FORM */
    if ($params->get('paytm_merchant_key') != '' && $params->get('paytm_merchant_mid') != '' && $params->get('paytm_merchant_website') != '') {
        ?>

        <div id="paytm-pg-spinner" class="paytm-pg-loader">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
            <div class="bounce4"></div>
            <div class="bounce5"></div>
        </div>
        <script type="application/javascript" crossorigin="anonymous" src="<?php echo PaytmHelper::getPaytmHostURL($PAYTM_ENV); ?>merchantpgpui/checkoutjs/merchants/<?php echo PAYTM_MERCHANT_MID; ?>.js"></script>
        <form class="form-validate" method="post" id="payForm" action="<?php echo $redirect_url; ?>">
            <div class="pg-main-form-div">
                <input type="hidden" name="paytmstring" value="<?php echo $params->get('paytm_merchant_key'); ?>" >

                <div class="img-logo" alt="Paytm Payments" title="Paytm Payments"><img src="<?php echo JURI::base() . 'modules/mod_pgpaytm/images/Paytm_logo.png'; ?>" /></div>
        <?php echo $introtext; ?>
                <div class="pg-email">
                    <div class="pg-email-label">
                        <p>Email*:</p>
                    </div>
                    <div class="pg-email-field">
                        <input class="required validate-email" id="email" tabindex="1" name="email" value="">
                    </div>
                </div>
                <div class="pg-mobile">
                    <div class="pg-mobile-label">
                        <p>Mobile*:</p>
                    </div>
                    <div class="pg-mobile-field">
                        <input type="tel" class="required validate-numeric" maxlength="10" id="mobile" tabindex="2" name="mobile" value="">
                    </div>
                </div>
                <input type="hidden" id="ORDER_ID" tabindex="3" maxlength="20" size="20" name="ORDER_ID" autocomplete="off" 
                       value="<?php echo "ORDS" . rand(10000, 99999999) ?>">
                <input type="hidden" id="CUST_ID" tabindex="4" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="">
                <input type="hidden" id="INDUSTRY_TYPE_ID" tabindex="5" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail">
                <input type="hidden" id="CHANNEL_ID" tabindex="6" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
                <input type="hidden" id="mid"   name="mid" autocomplete="off" value="<?php echo PAYTM_MERCHANT_MID; ?>">

                <input type="hidden" id="merchant_web"   name="merchant_web" autocomplete="off" value="<?php echo PAYTM_MERCHANT_WEBSITE; ?>">			

                <div class="pg-amount">
        <?php echo $amountLine; ?>
                </div>
                <div class="pg-submit" id="paytmDivbtn">
                    <input value="Pay With Paytm" type="submit" name="submit" id="paywithpaytm" class="validate pg-submit-button">
                    
                </div>
            </div>
        </form>
        <div class="loader"></div>
        <style type="text/css">
            #paytm-pg-spinner {margin: 20% auto 0;width: 70px;text-align: center;z-index: 999999;position: relative;display: none}

            #paytm-pg-spinner > div {width: 10px;height: 10px;background-color: #012b71;border-radius: 100%;display: inline-block;-webkit-animation: sk-bouncedelay 1.4s infinite ease-in-out both;animation: sk-bouncedelay 1.4s infinite ease-in-out both;}

            #paytm-pg-spinner .bounce1 {-webkit-animation-delay: -0.64s;animation-delay: -0.64s;}

            #paytm-pg-spinner .bounce2 {-webkit-animation-delay: -0.48s;animation-delay: -0.48s;}
            #paytm-pg-spinner .bounce3 {-webkit-animation-delay: -0.32s;animation-delay: -0.32s;}

            #paytm-pg-spinner .bounce4 {-webkit-animation-delay: -0.16s;animation-delay: -0.16s;}
            #paytm-pg-spinner .bounce4, #paytm-pg-spinner .bounce5{background-color: #48baf5;} 
            @-webkit-keyframes sk-bouncedelay {0%, 80%, 100% { -webkit-transform: scale(0) }40% { -webkit-transform: scale(1.0) }}

            @keyframes sk-bouncedelay { 0%, 80%, 100% { -webkit-transform: scale(0);transform: scale(0); } 40% { 
                                            -webkit-transform: scale(1.0); transform: scale(1.0);}}
            .paytm-overlay{width: 100%;position: fixed;top: 0px;opacity: .4;height: 100%;background: #000;display: none;}
            #errorDivPaytm {
                color: red !important;
            }

        </style>

        <script type="text/javascript">
            jQuery(window).on('load', function () {

                jQuery( '<div class="paytm-overlay paytm-pg-loader"></div>' ).insertBefore("body");
                function openJsCheckoutPopup(orderId, txnToken, amount)
                {
                    var config = {
                        "root": "",
                        "flow": "DEFAULT",
                        "data": {
                            "orderId": orderId,
                            "token": txnToken,
                            "tokenType": "TXN_TOKEN",
                            "amount": amount
                        },
                        "merchant": {
                            "redirect": true
                        },
                        "integration": {
                            "platform": "Joomla",
                            "version": "<?php echo JVERSION; ?>|2.0"
                        },
                        "handler": {
                    
                            "notifyMerchant": function (eventName, data) {
                                
                               if(eventName == 'SESSION_EXPIRED'){
                                location.reload(); 
                               }
                            }
                        }
                    };
                    if (window.Paytm && window.Paytm.CheckoutJS) {
                        // initialze configuration using init method 
                        window.Paytm.CheckoutJS.init(config).then(function onSuccess() {
                            // after successfully updating configuration, invoke checkoutjs
                            window.Paytm.CheckoutJS.invoke();

                            jQuery('.paytm-pg-loader').css("display", "none");

                        }).catch(function onError(error) {
                          //  console.log("error => ", error);
                        });
                    }
                }

                jQuery("#payForm").submit(function (e) {

                    e.preventDefault(); // avoid to execute the actual submit of the form.
                    var form = jQuery(this);
                    var url = form.attr('action');
                    jQuery("#errorDivPaytm").remove();
                    jQuery.ajax({
                        type: "POST",
                        url: url,
                        data: form.serialize(), // serializes the form's elements.
                        beforeSend: function () {
                            jQuery('.paytm-pg-loader').css("display", "block");
                        },
                        success: function (data)
                        {
                            var data_json = JSON.parse(data); // show response from the php script.
                            let amount = jQuery("input[name='TXN_AMOUNT']").val();
                            let orderid = jQuery("#ORDER_ID").val();
                            
                            if(data_json.response.txnToken!=''){
                                openJsCheckoutPopup(orderid, data_json.response.txnToken, amount);
                            }else{
                                 //console.log(data2.response.message);
                                 jQuery('.paytm-pg-loader').css("display", "none");
                                 jQuery("#paytmDivbtn").append("<div id='errorDivPaytm' >"+data_json.response.message+"</div>");
                            }
                          

                        }
                    });


                });


            });

        </script>


        <?php
    } else {
        echo "<p style='font-size: 14px;color:#b94a48;background: #f2dede;border-radius: 3px;padding:8px'>Set Merchant Key, Merchant Website and other parameters from the admin panel configurations.</p>";
    }
}
/* PAYTM FORM */
?>
</div>