<?php
/**
 * @package   PGPAYTM
 * @contact   www.paytm.com
 * @copyright 2010 paytm.com
 */
 
// no direct access
defined('_JEXEC') or die();
require_once(dirname(__FILE__).  DIRECTORY_SEPARATOR .'helper.php');
require JModuleHelper::getLayoutPath('mod_pgpaytm');
