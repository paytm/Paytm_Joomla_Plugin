<?php
/**
 * @package   PGPAYTM
 * @contact   www.paytm.com
 * @copyright 2010 paytm.com
 */
// No direct access
defined('_JEXEC') or die('Restricted access');

class OrderHistoryTableOrderHistory extends JTable
{
	
	function __construct(&$db)
	{
		parent::__construct('#__pgstatus', 'id', $db);
	}
}
