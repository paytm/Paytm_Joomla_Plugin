<?php
/**
 * @package   PGPAYTM
 * @contact   www.paytm.com
 * @copyright 2010 paytm.com
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JFormHelper::loadFieldClass('list');

class JFormFieldOrderHistory extends JFormFieldList
{
	protected $type = 'OrderHistory';
	protected function getOptions()
	{
		$db    = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('id,order_id,amount,status,txndate');
		$query->from('#__pgstatus');
		$db->setQuery((string) $query);
		$messages = $db->loadObjectList();
		$options  = array();

		if ($messages)
		{
			foreach ($messages as $message)
			{
				$options[] = JHtml::_('select.option', $message->id, $message->order_id, $message->amount, $message->status, $message->txndate);
			}
		}

		$options = array_merge(parent::getOptions(), $options);

		return $options;
	}
}
