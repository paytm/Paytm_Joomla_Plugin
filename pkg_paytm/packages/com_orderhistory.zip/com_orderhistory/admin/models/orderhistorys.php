<?php
/**
 * @package   PGPAYTM
 * @contact   www.paytm.com
 * @copyright 2010 paytm.com
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class OrderHistoryModelOrderHistorys extends JModelList
{
	
	protected function getListQuery()
	{
		// Initialize variables.
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);

		// Create the base select statement.
		$query->select(array('pgs.*','pgd.email'))
			  ->from($db->quoteName('#__pgstatus', 'pgs'))			  	  
			  ->join('INNER', $db->quoteName('#__pgdata', 'pgd') . ' ON (' . $db->quoteName('pgs.order_id') . ' = ' . $db->quoteName('pgd.order_id') . ')')
			  ->order($db->quoteName('pgs.id') . ' DESC');

		return $query;
	}
}
