<?php
/**
 * @package   PGPAYTM
 * @contact   www.paytm.com
 * @copyright 2010 paytm.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class OrderHistoryController extends JControllerLegacy
{
	protected $default_view = 'orderhistorys';
}
