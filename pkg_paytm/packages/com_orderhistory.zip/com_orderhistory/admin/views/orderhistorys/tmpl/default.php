<?php
/**
 * @package   PGPAYTM
 * @contact   www.paytm.com
 * @copyright 2010 paytm.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
JHtml::_('behavior.multiselect');
?>
<form action="index.php?option=com_orderhistory&view=orderhistorys" method="post" id="adminForm" name="adminForm">
	<table class="table table-striped table-hover">
		<thead>
		<tr>
			<th width="15%"><?php echo JText::_('ID'); ?></th>
			<th width="15%"><?php echo JText::_('Order ID') ;?></th>
			<th width="25%"><?php echo JText::_('Email ID') ;?></th>
			<th width="15%"><?php echo JText::_('Amount') ;?></th>			
			<th width="15%"><?php echo JText::_('Status') ;?></th>			
			<th width="15%"><?php echo JText::_('Transaction Date') ;?></th>			
		</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="6">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<tbody>
			<?php if (!empty($this->items)) : ?>
				<?php foreach ($this->items as $i => $row) : ?>

					<tr>
						<td><?php echo $row->id; //echo $this->pagination->getRowOffset($i); ?></td>
						<td><?php echo $row->order_id; ?></td>		
						<td><?php echo $row->email; ?></td>							
						<td><?php echo $row->amount; ?></td>						
						<td><?php echo $row->status; ?></td>						
						<td><?php echo $row->txndate; ?></td>						
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
		</tbody>
	</table>
</form>

